# registro.html.

A Pen created on CodePen.

Original URL: [https://codepen.io/Alexa-Vazquez/pen/MYjGXWw](https://codepen.io/Alexa-Vazquez/pen/MYjGXWw).

